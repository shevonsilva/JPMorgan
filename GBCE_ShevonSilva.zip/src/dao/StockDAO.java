package dao;

import java.util.ArrayList;

public class StockDAO {

	private String symbol;
	private String type;
	private int lastDividend;
	private double fixedDivided;
	private int parValue;

	private static final double EMPTY = 0;

	public StockDAO(String symbol, String type, int lastDividend, int parValue) {
		this(symbol, type, lastDividend, EMPTY, parValue);
	}

	public StockDAO(String symbol, String type, int lastDividend,
			double fixedDivided, int parValue) {
		this.symbol = symbol;
		this.type = type;
		this.lastDividend = lastDividend;
		this.fixedDivided = fixedDivided;
		this.parValue = parValue;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLastDividend() {
		return lastDividend;
	}

	public void setLastDividend(int lastDividend) {
		this.lastDividend = lastDividend;
	}

	public double getFixedDivided() {
		return fixedDivided;
	}

	public void setFixedDivided(double fixedDivided) {
		this.fixedDivided = fixedDivided;
	}

	public int getParValue() {
		return parValue;
	}

	public void setParValue(int parValue) {
		this.parValue = parValue;
	}

	public String getSymbol() {
		return symbol;
	}

	public static ArrayList<StockDAO> getStock() throws DataException {
		ArrayList<StockDAO> s = new ArrayList<StockDAO>();
		for (String[] row : db.Stock.getStock()) {
			try {
				s.add(new StockDAO(
						row[db.Stock.SYMBOL],
						row[db.Stock.TYPE],
						Integer.parseInt(row[db.Stock.LAST_DIVIDEND]),
						(row[db.Stock.FIXED_DIVIDEND].equals("") || row[db.Stock.FIXED_DIVIDEND] == null) ? EMPTY
								: Double.parseDouble(row[db.Stock.FIXED_DIVIDEND]),
						Integer.parseInt(row[db.Stock.PAR_VALUE])));
			} catch (NumberFormatException nfe) {
				throw new DataException("Data coversion exception. Message:"
						+ nfe.getMessage());
			}
		}
		return s;
	}

	public static StockDAO search(String symbol) throws DataException {
		ArrayList<StockDAO> s = new ArrayList<StockDAO>();
		for (String[] row : db.Stock.getStock()) {
			if (row[db.Stock.SYMBOL].equals(symbol))
				try {
					return new StockDAO(
							row[db.Stock.SYMBOL],
							row[db.Stock.TYPE],
							Integer.parseInt(row[db.Stock.LAST_DIVIDEND]),
							row[db.Stock.FIXED_DIVIDEND].equals("") ? EMPTY
									: Double.parseDouble(row[db.Stock.FIXED_DIVIDEND]),
							Integer.parseInt(row[db.Stock.PAR_VALUE]));
				} catch (NumberFormatException nfe) {
					throw new DataException(
							"Data coversion exception. Message:"
									+ nfe.getMessage());
				}
		}
		return null;
	}
}
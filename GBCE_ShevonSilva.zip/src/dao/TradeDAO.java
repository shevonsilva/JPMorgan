package dao;

import java.util.ArrayList;
import java.util.Date;

import db.DbException;

public class TradeDAO {

	private Date timestamp;
	private int quantityOfShares;
	private int price;

	public enum BuyOrSell {
		BUY, SELL
	}

	BuyOrSell buyOrSell;

	public TradeDAO(Date timestamp, int quantityOfShares, BuyOrSell buyOrSell,
			int price) {
		this.timestamp = timestamp;
		this.quantityOfShares = quantityOfShares;
		this.buyOrSell = buyOrSell;
		this.price = price;
	}

	public int getQuantityOfShares() {
		return quantityOfShares;
	}

	public void setQuantityOfShares(int quantityOfShares) {
		this.quantityOfShares = quantityOfShares;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public boolean isBuy() {
		return buyOrSell == BuyOrSell.BUY;
	}

	public boolean isSell() {
		return buyOrSell == buyOrSell.SELL;
	}

	@SuppressWarnings("deprecation")
	public static ArrayList<TradeDAO> getTrade() throws DataException {
		ArrayList<TradeDAO> t = new ArrayList<TradeDAO>();
		for (String[] row : db.Trade.getTrade()) {
			try {
				t.add(new TradeDAO(
						new Date(row[db.Trade.TIMESTAMP]),
						Integer.parseInt(row[db.Trade.QUANTITY_OF_SHARES]),
						row[db.Trade.BUY_OR_SELL].equals(db.Trade.BUY) ? BuyOrSell.BUY
								: BuyOrSell.SELL, Integer
								.parseInt(row[db.Trade.PRICE])));
			} catch (NumberFormatException nfe) {
				throw new DataException("Data coversion exception. Message:"
						+ nfe.getMessage());
			}
		}
		return t;
	}

	public void addToDatabase() throws DbException {
		db.Trade.add(getTimestamp(), getQuantityOfShares(),
				isBuy() ? db.Trade.BUY : db.Trade.SELL, getPrice());
	}
}
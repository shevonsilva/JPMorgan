package db;

/**
 * Represents Stock table
 * 
 * @author Shevon
 *
 */
public class Stock {
	// column numbers starting with 0
	public static final int SYMBOL = 0;
	public static final int TYPE = 1;
	public static final int LAST_DIVIDEND = 2;
	public static final int FIXED_DIVIDEND = 3;
	public static final int PAR_VALUE = 4;

	public static final String COMMON = "Common";
	public static final String PREFERRED = "Preferred";

	private static String[][] stock = new String[][] {
			{ "TEA", COMMON, "0", "", "100" },
			{ "POP", COMMON, "8", "", "100" },
			{ "ALE", COMMON, "23", "", "60" },
			{ "GIN", PREFERRED, "8", "2", "100" },
			{ "JOE", COMMON, "13", "", "250" } };

	public static String[][] getStock() {
		return stock;
	}
}
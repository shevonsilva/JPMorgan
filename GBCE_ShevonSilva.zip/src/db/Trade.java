package db;

import java.util.Date;

/**
 * Represents Trade table.
 * 
 * @author Shevon
 */
public class Trade {
	// column numbers starting with 0
	public static final int TIMESTAMP = 0;
	public static final int QUANTITY_OF_SHARES = 1;
	public static final int BUY_OR_SELL = 2;
	public static final int PRICE = 3;

	public static final int NO_OF_COLUMNS = 4;
	private static final int INITIAL_SIZE = 2;
	private static final double LOAD_FACTOR = 1.5;
	private static int length = 0;

	public static final String BUY = "buy";
	public static final String SELL = "sell";

	private static String[][] trade = new String[INITIAL_SIZE][NO_OF_COLUMNS];

	public static String[][] getTrade() {
		return trade;
	}

	/**
	 * Add a row to the table.
	 * 
	 * @param timestamp
	 * @param quantityOfShares
	 * @param buySell
	 * @param price
	 */
	public static void add(Date timestamp, int quantityOfShares,
			String buySell, int price) throws DbException {
		if (length >= trade.length)
			increaseTradeSize();
		if (!(buySell.equals(BUY) || buySell.equals(SELL)))
			throw new DbException("Constrain failed: Invalid value for the "
					+ BUY_OR_SELL + " column.");
		trade[length++] = new String[] { timestamp.toString(),
				String.valueOf(quantityOfShares), buySell,
				String.valueOf(price) };
	}

	/**
	 * Expanding the size of the trade array.
	 */
	private static void increaseTradeSize() {
		final int newLength = (int) (trade.length * LOAD_FACTOR);
		String[][] nTrade = new String[newLength][NO_OF_COLUMNS];
		System.arraycopy(trade, 0, nTrade, 0, trade.length);
		trade = nTrade;
	}
}
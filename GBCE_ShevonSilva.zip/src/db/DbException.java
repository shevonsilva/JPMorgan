package db;

public class DbException extends Exception {
	public DbException(String message) {
		super(message);
	}
}

import console.MainScreen;

public class Boot {

	public static void main(String[] args) {
		new MainScreen().display();
	}

}

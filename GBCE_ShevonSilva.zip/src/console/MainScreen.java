package console;

import java.io.IOException;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import businesslogic.Stock;
import businesslogic.Stocks;
import businesslogic.Trade;
import dao.TradeDAO.BuyOrSell;

public class MainScreen {
	private static String StockQuery = "Please enter the stock symbol: ";

	public void display() {
		System.out.println("\n\n\n\nGlobal Beverage Corporation Exchange\n\n"
				+ "1)\tDividend yield\n" + "2)\tP/E Ratio\n"
				+ "3)\tRecord a trade\n" + "4)\tVolume Weighted Stock Price\n"
				+ "5)\tGBCE All Share Index\n" + "6)\tExit"
				+ "\n\nEnter your selection: ");
		Scanner reader = new Scanner(System.in);
		int n = getInteger(reader);
		Stock stock;
		switch (n) {
		case 1:
			System.out.println(StockQuery);
			String symbolD = reader.next();
			System.out.println("Enter a market price: ");
			int marketPriceD = getInteger(reader);
			stock = Stocks.search(symbolD);
			if (stock == null) {
				System.out.println("No Records found");
				break;
			}
			System.out.println("Dividend Yield: "
					+ stock.dividendYield(marketPriceD));
			break;
		case 2:
			System.out.println(StockQuery);
			String symbolPE = reader.next();
			System.out.println("Enter a market price: ");
			int marketPricePE = getInteger(reader);
			stock = Stocks.search(symbolPE);
			if (stock == null) {
				System.out.println("No Records found");
				break;
			}
			System.out.println("P/E Ratio: " + stock.pERatio(marketPricePE));
			// alternatively new Stock(symbolPE).pERatio(marketPricePE) can be
			// used too.
			break;
		case 3:
			System.out.println(StockQuery);
			String symbolT = reader.next();
			System.out.println("Recording a Trade");
			System.out.println("Enter the quantity of shares: ");

			int qos = getInteger(reader);
			String bos = "";
			do {
				System.out.println("Buy (enter b) or Sell (enter s): ");
				bos = reader.next();
			} while(!(bos.equals("b") || bos.equals("s")));
			System.out.println("Enter the trade price: ");
			int price = getInteger(reader);

			stock = Stocks.search(symbolT);
			if (stock == null) {
				System.out.println("No Records found");
				break;
			}
			stock.addTrade(new Trade(new Date(), qos,
					(bos.equals("b") ? BuyOrSell.BUY : BuyOrSell.SELL), price));
			System.out.println("The trade was successfully added.");
			break;
		case 4:
			System.out.println(StockQuery);
			String symbolWSP = reader.next();
			stock = Stocks.search(symbolWSP);
			if (stock == null) {
				System.out.println("No Records found");
				break;
			}
			// 15 min duration
			System.out.println("Volume Weighted Stock Price: "
					+ stock.volumeWeightedStockPrice(15));
			break;
		case 5:
			System.out.println("GBCE All Share Index: "
					+ Stocks.allShareIndex());
			break;
		case 6:
			reader.close();
			System.exit(0);
		}
		display();
		reader.close();
	}

	private int getInteger(Scanner reader) {
		int i = 0;
		boolean done = false;
		while (!done) {
			try {
				i = reader.nextInt();
				done = true;
			} catch (InputMismatchException ime) {
				System.out.println("Enter an integer value: ");
				reader.next();
			}
		}
		return i;
	}
}
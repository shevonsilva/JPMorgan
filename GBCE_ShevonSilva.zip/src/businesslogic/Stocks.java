package businesslogic;

import java.util.ArrayList;

import businesslogic.math.FinanceCalculator;
import dao.DataException;
import dao.StockDAO;

public class Stocks {

	static ArrayList<Stock> stocks;
	static {
		stocks = new ArrayList<Stock>();
		ArrayList<StockDAO> stockDAOs;
		try {
			stockDAOs = StockDAO.getStock();
			for (StockDAO stockDAO : stockDAOs)
				stocks.add(new Stock(stockDAO.getSymbol()));
		} catch (DataException e) {
			e.printStackTrace();
			// Consider as a critical condition.
			System.exit(0);
		}
	}

	public static ArrayList<Stock> getStocks() {
		return stocks;
	}

	public Stocks() {

	}

	public static void addStock(Stock stock) {
		stocks.add(stock);
	}

	public static Stock search(String stockSymbol) {
		for (Stock stock : stocks) {
			if (stock.getStockDAO().getSymbol().equals(stockSymbol))
				return stock;
		}
		return null;
	}

	public static double allShareIndex() {
		return FinanceCalculator.allShareIndex(stocks);
	}
}

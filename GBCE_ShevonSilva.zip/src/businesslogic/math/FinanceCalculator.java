package businesslogic.math;

import java.util.ArrayList;

import businesslogic.Stock;
import businesslogic.Trade;

public class FinanceCalculator {

	public static double CommonDividendYield(int lastDividend, int marketPrice) {
		return ((double) lastDividend) / marketPrice;
	}

	public static double PreferredDividendYield(double fixedDividend,
			int parValue, int marketPrice) {
		return (fixedDividend * parValue) / marketPrice;
	}

	public static double pERatio(int marketPrice, double dividend) {
		return marketPrice / dividend;
	}

	public static double volumeWeightedStockPrice(ArrayList<Trade> trades) {
		if (trades.size() == 0)
			return 0;

		long SumOfTradePricesQuantities = 0;
		long SumOfQuantities = 0;
		for (Trade trade : trades) {
			SumOfTradePricesQuantities += trade.getTradeDAO().getPrice()
					* trade.getTradeDAO().getQuantityOfShares();
			SumOfQuantities += trade.getTradeDAO().getQuantityOfShares();
		}
		return SumOfTradePricesQuantities / SumOfQuantities;
	}

	public static double allShareIndex(ArrayList<Stock> stocks) {
		ArrayList<Integer> prices = new ArrayList<Integer>();
		for (Stock stock : stocks) {
			for (Trade trade : stock.getTrades())
				prices.add(trade.getTradeDAO().getPrice());
		}
		return Calculator.geometricMean(prices);
	}
}

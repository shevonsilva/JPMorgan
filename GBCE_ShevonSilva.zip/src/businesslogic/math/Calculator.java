package businesslogic.math;

import java.util.ArrayList;

public class Calculator {

	public static double geometricMean(ArrayList<Integer> values) {
		double multiplications = 1;
		for (int i : values)
			multiplications *= i;
		return root(multiplications, values.size());
	}

	public static double root(double num, double root) {
		if (num < 0) {
			return -Math.pow(Math.abs(num), (1 / root));
		}
		return Math.pow(num, 1.0 / root);
	}
}

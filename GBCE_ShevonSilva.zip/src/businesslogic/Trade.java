package businesslogic;

import java.util.Date;

import dao.TradeDAO;
import dao.TradeDAO.BuyOrSell;

public class Trade {

	private TradeDAO tradeDAO;

	public Trade(Date timestamp, int quantityOfShares, BuyOrSell buyOrSell,
			int price) {
		tradeDAO = new TradeDAO(timestamp, quantityOfShares, buyOrSell, price);
	}

	public TradeDAO getTradeDAO() {
		return tradeDAO;
	}
}

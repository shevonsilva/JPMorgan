package businesslogic;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import businesslogic.math.FinanceCalculator;
import dao.DataException;
import dao.StockDAO;
import dao.TradeDAO.BuyOrSell;

public class Stock {

	private StockDAO stockDAO;

	private ArrayList<Trade> trades;

	public ArrayList<Trade> getTrades() {
		return trades;
	}

	public Stock(String stockSymbol) throws DataException {
		stockDAO = StockDAO.search(stockSymbol);
		trades = new ArrayList<Trade>();
	}

	public double dividendYield(int marketPrice) {
		switch (stockDAO.getType()) {
		case db.Stock.COMMON:
			return FinanceCalculator.CommonDividendYield(
					stockDAO.getLastDividend(), marketPrice);
		case db.Stock.PREFERRED:
			return FinanceCalculator.PreferredDividendYield(
					stockDAO.getFixedDivided(), stockDAO.getParValue(),
					marketPrice);
		default:
			throw new RuntimeException("Invalid Entry in database");
		}
	}

	public double pERatio(int marketPrice) {
		return FinanceCalculator.pERatio(marketPrice,
				dividendYield(marketPrice));
	}

	/**
	 * @param duration
	 *            last time period in minutes.
	 * @return
	 */
	public double volumeWeightedStockPrice(int duration) {
		Date current = new Date();
		ArrayList<Trade> tradesWithinDuration = new ArrayList<Trade>();
		for (Trade trade : trades) {
			long diff = current.getTime()
					- trade.getTradeDAO().getTimestamp().getTime();
			if (TimeUnit.MILLISECONDS.toMinutes(diff) <= duration)
				tradesWithinDuration.add(trade);
		}
		return FinanceCalculator.volumeWeightedStockPrice(tradesWithinDuration);
	}

	public void addTrade(Date timestamp, int quantityOfShares,
			BuyOrSell buyOrSell, int price) {
		trades.add(new Trade(timestamp, quantityOfShares, buyOrSell, price));
	}

	public void addTrade(Trade trade) {
		trades.add(trade);
	}

	public StockDAO getStockDAO() {
		return stockDAO;
	}
}
